package ecoroute;

import ecoroute.engine.Graph;
import ecoroute.exception.OverloadException;
import ecoroute.exception.PathNotFoundException;
import ecoroute.model.DeliveryOrder;
import ecoroute.model.Vehicle;
import ecoroute.service.DispatchService;
import ecoroute.service.FleetManager;

public class Main {
    public static void main(String[] args) {
        System.out.println(">>> Initializing EcoRoute Logistics Dispatcher...");

       
        Graph roadNetwork = new Graph();
        
        
        roadNetwork.addRoadSegment("NorthHub", "RidgePass", 65.0, 7.5);   // +7.5% steep slope
        roadNetwork.addRoadSegment("RidgePass", "SouthPort", 77.5, 6.0);   // +6.0% uphill

        roadNetwork.addRoadSegment("NorthHub", "BypassValley", 45.0, -0.5);
        roadNetwork.addRoadSegment("BypassValley", "RiverWest", 68.2, 0.8);
        roadNetwork.addRoadSegment("RiverWest", "SouthPort", 48.0, 0.2);

       
        FleetManager fleetManager = new FleetManager();
        Vehicle truckA = new Vehicle("TRK-VOLVO-FH16", "Volvo FH16 Heavy Freight", 9000.0, 25000.0, 31.0);
        fleetManager.registerVehicle(truckA);

        DispatchService dispatcher = new DispatchService();

        
        try {
            System.out.println("\n[SCENARIO 1] Executing Dispatch for Standard Order (14,500 kg Payload):");
            DeliveryOrder validOrder = new DeliveryOrder("ORD-2026-A1", "NorthHub", "SouthPort", 14500.0);
            dispatcher.executeDispatch(roadNetwork, truckA, validOrder);
        } catch (OverloadException | PathNotFoundException e) {
            System.err.println("Dispatch Failure: " + e.getMessage());
        }

        
        try {
            System.out.println("[SCENARIO 2] Attempting Overloaded Dispatch (28,000 kg on a 25,000 kg Truck):");
            DeliveryOrder heavyOrder = new DeliveryOrder("ORD-2026-OVERLOAD", "NorthHub", "SouthPort", 28000.0);
            dispatcher.executeDispatch(roadNetwork, truckA, heavyOrder);
        } catch (OverloadException e) {
            System.out.printf("Caught Expected Exception: %s%n%n", e.getMessage());
        } catch (PathNotFoundException e) {
            System.err.println("Routing Failure: " + e.getMessage());
        }

       
        try {
            System.out.println("[SCENARIO 3] Attempting Routing to Disconnected Node (IslandHub):");
            roadNetwork.addHub("IslandHub");
            DeliveryOrder orphanOrder = new DeliveryOrder("ORD-2026-UNREACHABLE", "NorthHub", "IslandHub", 5000.0);
            dispatcher.executeDispatch(roadNetwork, truckA, orphanOrder);
        } catch (PathNotFoundException e) {
            System.out.printf("Caught Expected Exception: %s%n", e.getMessage());
        } catch (OverloadException e) {
            System.err.println("Dispatch Failure: " + e.getMessage());
        }
    }
}