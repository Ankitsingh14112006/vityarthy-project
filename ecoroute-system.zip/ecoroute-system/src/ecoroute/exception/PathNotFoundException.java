package ecoroute.exception;

public class PathNotFoundException extends Exception {
    public PathNotFoundException(String message) {
        super(message);
    }
}