package ecoroute.model;

public class DeliveryOrder {
    private final String orderId;
    private final String originHub;
    private final String destHub;
    private final double cargoWeightKg;

    public DeliveryOrder(String orderId, String originHub, String destHub, double cargoWeightKg) {
        this.orderId = orderId;
        this.originHub = originHub;
        this.destHub = destHub;
        this.cargoWeightKg = cargoWeightKg;
    }

    public String getOrderId() { return orderId; }
    public String getOriginHub() { return originHub; }
    public String getDestHub() { return destHub; }
    public double getCargoWeightKg() { return cargoWeightKg; }
}