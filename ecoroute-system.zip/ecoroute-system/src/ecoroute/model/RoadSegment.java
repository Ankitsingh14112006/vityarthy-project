package ecoroute.model;

public class RoadSegment {
    private final String sourceHub;
    private final String destHub;
    private final double distanceKm;
    private final double gradientPercent; // e.g., +4.5% uphill, -2.0% downhill

    public RoadSegment(String sourceHub, String destHub, double distanceKm, double gradientPercent) {
        this.sourceHub = sourceHub;
        this.destHub = destHub;
        this.distanceKm = distanceKm;
        this.gradientPercent = gradientPercent;
    }

    public String getSourceHub() { return sourceHub; }
    public String getDestHub() { return destHub; }
    public double getDistanceKm() { return distanceKm; }
    public double getGradientPercent() { return gradientPercent; }
}