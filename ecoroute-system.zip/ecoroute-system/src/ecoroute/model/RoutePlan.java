package ecoroute.model;

import java.util.List;

public class RoutePlan {
    private final List<String> waypoints;
    private final double totalDistanceKm;
    private final double totalCO2Kg;
    private final double totalFuelLiters;

    public RoutePlan(List<String> waypoints, double totalDistanceKm, double totalCO2Kg, double totalFuelLiters) {
        this.waypoints = waypoints;
        this.totalDistanceKm = totalDistanceKm;
        this.totalCO2Kg = totalCO2Kg;
        this.totalFuelLiters = totalFuelLiters;
    }

    public List<String> getWaypoints() { return waypoints; }
    public double getTotalDistanceKm() { return totalDistanceKm; }
    public double getTotalCO2Kg() { return totalCO2Kg; }
    public double getTotalFuelLiters() { return totalFuelLiters; }
}