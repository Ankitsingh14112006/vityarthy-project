package ecoroute.model;

public class Vehicle {
    private final String id;
    private final String modelName;
    private final double curbWeightKg;
    private final double maxPayloadKg;
    private final double baseFuelLPer100Km;

    public Vehicle(String id, String modelName, double curbWeightKg, double maxPayloadKg, double baseFuelLPer100Km) {
        this.id = id;
        this.modelName = modelName;
        this.curbWeightKg = curbWeightKg;
        this.maxPayloadKg = maxPayloadKg;
        this.baseFuelLPer100Km = baseFuelLPer100Km;
    }

    public String getId() { return id; }
    public String getModelName() { return modelName; }
    public double getCurbWeightKg() { return curbWeightKg; }
    public double getMaxPayloadKg() { return maxPayloadKg; }
    public double getBaseFuelLPer100Km() { return baseFuelLPer100Km; }
}