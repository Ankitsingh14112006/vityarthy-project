package ecoroute.service;

import ecoroute.engine.Graph;
import ecoroute.engine.RouteOptimizer;
import ecoroute.exception.OverloadException;
import ecoroute.exception.PathNotFoundException;
import ecoroute.model.DeliveryOrder;
import ecoroute.model.RoutePlan;
import ecoroute.model.Vehicle;

public class DispatchService {
    private final RouteOptimizer optimizer = new RouteOptimizer();

    public void executeDispatch(Graph graph, Vehicle vehicle, DeliveryOrder order) 
            throws OverloadException, PathNotFoundException {
        
       
        if (order.getCargoWeightKg() > vehicle.getMaxPayloadKg()) {
            throw new OverloadException(String.format(
                "Order %s rejected: Cargo weight (%.1f kg) exceeds vehicle %s maximum capacity (%.1f kg).",
                order.getOrderId(), order.getCargoWeightKg(), vehicle.getId(), vehicle.getMaxPayloadKg()
            ));
        }

        double grossWeightKg = vehicle.getCurbWeightKg() + order.getCargoWeightKg();

        
        RoutePlan ecoPlan = optimizer.findGreenestRoute(
            graph, order.getOriginHub(), order.getDestHub(), grossWeightKg, vehicle.getBaseFuelLPer100Km()
        );

       
        RoutePlan baselinePlan = optimizer.findShortestDistanceRoute(
            graph, order.getOriginHub(), order.getDestHub(), grossWeightKg, vehicle.getBaseFuelLPer100Km()
        );

        printAuditManifest(order, vehicle, ecoPlan, baselinePlan);
    }

    private void printAuditManifest(DeliveryOrder order, Vehicle vehicle, RoutePlan eco, RoutePlan base) {
        double co2Saved = base.getTotalCO2Kg() - eco.getTotalCO2Kg();
        double fuelSaved = base.getTotalFuelLiters() - eco.getTotalFuelLiters();
        double percentReduction = (co2Saved / base.getTotalCO2Kg()) * 100.0;

        System.out.println("================================================================================");
        System.out.println("                        ECOROUTE AUDIT MANIFEST REPORT                          ");
        System.out.println("================================================================================");
        System.out.printf("Order Reference     : %s%n", order.getOrderId());
        System.out.printf("Assigned Vehicle    : %s (%s)%n", vehicle.getId(), vehicle.getModelName());
        System.out.printf("Payload / Capacity  : %.1f kg / %.1f kg (%.1f%% Utilized)%n", 
            order.getCargoWeightKg(), vehicle.getMaxPayloadKg(), 
            (order.getCargoWeightKg() / vehicle.getMaxPayloadKg()) * 100.0);
        System.out.printf("Route Waypoints     : %s%n", String.join(" -> ", eco.getWaypoints()));
        System.out.println("--------------------------------------------------------------------------------");
        System.out.printf("OPTIMIZED (GREEN) ROUTE   : %.2f km | %.2f kg CO2 | %.2f Liters Diesel%n",
            eco.getTotalDistanceKm(), eco.getTotalCO2Kg(), eco.getTotalFuelLiters());
        System.out.printf("BASELINE (SHORTEST PATH)  : %.2f km | %.2f kg CO2 | %.2f Liters Diesel%n",
            base.getTotalDistanceKm(), base.getTotalCO2Kg(), base.getTotalFuelLiters());
        System.out.println("--------------------------------------------------------------------------------");
        System.out.printf("NET CARBON REDUCTION      : %.2f kg CO2 (%.2f%% Saved)%n", co2Saved, percentReduction);
        System.out.printf("NET FUEL CONSERVED        : %.2f Liters%n", fuelSaved);
        System.out.println("STATUS                    : DISPATCH PERMIT APPROVED");
        System.out.println("================================================================================\n");
    }
}