package ecoroute.service;

import ecoroute.model.Vehicle;
import java.util.HashMap;
import java.util.Map;

public class FleetManager {
    private final Map<String, Vehicle> fleet = new HashMap<>();

    public void registerVehicle(Vehicle v) {
        fleet.put(v.getId(), v);
    }

    public Vehicle getVehicle(String vehicleId) {
        return fleet.get(vehicleId);
    }
}