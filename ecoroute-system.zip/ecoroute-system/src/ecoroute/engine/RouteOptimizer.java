package ecoroute.engine;

import ecoroute.exception.PathNotFoundException;
import ecoroute.model.RoadSegment;
import ecoroute.model.RoutePlan;
import java.util.*;

public class RouteOptimizer {

    private record NodeCost(String hub, double cost) {}

    public RoutePlan findGreenestRoute(Graph graph, String origin, String dest, 
                                      double grossWeightKg, double baseFuelRate) 
            throws PathNotFoundException {
        
        Map<String, Double> minCO2 = new HashMap<>();
        Map<String, RoadSegment> edgeTo = new HashMap<>();
        PriorityQueue<NodeCost> pq = new PriorityQueue<>(Comparator.comparingDouble(NodeCost::cost));

        for (String hub : graph.getAllHubs()) {
            minCO2.put(hub, Double.POSITIVE_INFINITY);
        }
        minCO2.put(origin, 0.0);
        pq.add(new NodeCost(origin, 0.0));

        while (!pq.isEmpty()) {
            NodeCost curr = pq.poll();
            if (curr.hub().equals(dest)) break;
            if (curr.cost() > minCO2.get(curr.hub())) continue;

            for (RoadSegment edge : graph.getNeighbors(curr.hub())) {
                double segmentCO2 = EmissionCalculator.calculateSegmentCO2(
                    edge.getDistanceKm(), edge.getGradientPercent(), grossWeightKg, baseFuelRate
                );
                double newCost = minCO2.get(curr.hub()) + segmentCO2;

                if (newCost < minCO2.get(edge.getDestHub())) {
                    minCO2.put(edge.getDestHub(), newCost);
                    edgeTo.put(edge.getDestHub(), edge);
                    pq.add(new NodeCost(edge.getDestHub(), newCost));
                }
            }
        }

        if (minCO2.get(dest) == Double.POSITIVE_INFINITY) {
            throw new PathNotFoundException("No viable path found from " + origin + " to " + dest);
        }

        return reconstructPlan(edgeTo, origin, dest, minCO2.get(dest));
    }

    
    public RoutePlan findShortestDistanceRoute(Graph graph, String origin, String dest, 
                                              double grossWeightKg, double baseFuelRate) 
            throws PathNotFoundException {
        
        Map<String, Double> minDistance = new HashMap<>();
        Map<String, RoadSegment> edgeTo = new HashMap<>();
        PriorityQueue<NodeCost> pq = new PriorityQueue<>(Comparator.comparingDouble(NodeCost::cost));

        for (String hub : graph.getAllHubs()) {
            minDistance.put(hub, Double.POSITIVE_INFINITY);
        }
        minDistance.put(origin, 0.0);
        pq.add(new NodeCost(origin, 0.0));

        while (!pq.isEmpty()) {
            NodeCost curr = pq.poll();
            if (curr.hub().equals(dest)) break;
            if (curr.cost() > minDistance.get(curr.hub())) continue;

            for (RoadSegment edge : graph.getNeighbors(curr.hub())) {
                double newDist = minDistance.get(curr.hub()) + edge.getDistanceKm();
                if (newDist < minDistance.get(edge.getDestHub())) {
                    minDistance.put(edge.getDestHub(), newDist);
                    edgeTo.put(edge.getDestHub(), edge);
                    pq.add(new NodeCost(edge.getDestHub(), newDist));
                }
            }
        }

        if (minDistance.get(dest) == Double.POSITIVE_INFINITY) {
            throw new PathNotFoundException("No path exists connecting " + origin + " to " + dest);
        }

        
        double accumulatedCO2 = 0.0;
        String curr = dest;
        while (!curr.equals(origin)) {
            RoadSegment edge = edgeTo.get(curr);
            accumulatedCO2 += EmissionCalculator.calculateSegmentCO2(
                edge.getDistanceKm(), edge.getGradientPercent(), grossWeightKg, baseFuelRate
            );
            curr = edge.getSourceHub();
        }

        return reconstructPlan(edgeTo, origin, dest, accumulatedCO2);
    }

    private RoutePlan reconstructPlan(Map<String, RoadSegment> edgeTo, String origin, String dest, double finalCO2) {
        LinkedList<String> path = new LinkedList<>();
        String current = dest;
        path.addFirst(current);
        double totalDist = 0.0;

        while (!current.equals(origin)) {
            RoadSegment edge = edgeTo.get(current);
            totalDist += edge.getDistanceKm();
            current = edge.getSourceHub();
            path.addFirst(current);
        }

        double fuelLiters = EmissionCalculator.co2ToFuelLiters(finalCO2);
        return new RoutePlan(path, totalDist, finalCO2, fuelLiters);
    }
}