package ecoroute.engine;

public class EmissionCalculator {
    public static final double DIESEL_CO2_FACTOR = 2.68; 

    public static double calculateSegmentCO2(double distanceKm, double gradePercent, 
                                            double totalMassKg, double baseFuelLPer100Km) {
       
        double weightFactor = 1.0 + ((totalMassKg - 3000.0) / 10000.0) * 0.35;

        
        double slopePenalty = 1.0;
        if (gradePercent > 0) {
            slopePenalty += (gradePercent * 0.12); 
        } else {
            slopePenalty += (gradePercent * 0.04); 
            slopePenalty = Math.max(0.65, slopePenalty); 
        }

        double fuelBurnLiters = (distanceKm / 100.0) * baseFuelLPer100Km * weightFactor * slopePenalty;
        return fuelBurnLiters * DIESEL_CO2_FACTOR;
    }

    public static double co2ToFuelLiters(double co2Kg) {
        return co2Kg / DIESEL_CO2_FACTOR;
    }
}