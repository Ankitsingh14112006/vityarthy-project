package ecoroute.engine;

import ecoroute.model.RoadSegment;
import java.util.*;

public class Graph {
    private final Map<String, List<RoadSegment>> adjList = new HashMap<>();

    public void addHub(String hubId) {
        adjList.putIfAbsent(hubId, new ArrayList<>());
    }

    public void addRoadSegment(String src, String dest, double distanceKm, double gradientPercent) {
        addHub(src);
        addHub(dest);
        adjList.get(src).add(new RoadSegment(src, dest, distanceKm, gradientPercent));
    }

    public List<RoadSegment> getNeighbors(String hubId) {
        return adjList.getOrDefault(hubId, Collections.emptyList());
    }

    public Set<String> getAllHubs() {
        return adjList.keySet();
    }
}